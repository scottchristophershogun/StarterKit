Key concepts - https://www.notion.so/shogun/Shogun-Frontend-Documentation-0efc38e4e9554c94ba97aae30d253527#5c13662417ae45f5979c074e7279975c
Developer guide - https://www.notion.so/shogun/Shogun-Frontend-Documentation-0efc38e4e9554c94ba97aae30d253527#1aa84ddde96741dd80d5ceca789a778e
